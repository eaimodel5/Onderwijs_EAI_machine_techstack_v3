import math

def e_ai_score(P, W_V, D_A, D_B, T, A, V, M):
    # Extended E_AI* formule met mirror factor M
    return math.sqrt(
        0.3*(P*W_V) +
        0.3*(D_A*D_B) +
        0.2*(T*A) +
        0.15*V +
        0.05*M
    )

# Voorbeeld
if __name__ == "__main__":
    print("E_AI* demo:", e_ai_score(0.8,0.7,0.9,0.6,0.7,0.8,0.9,1.0))
