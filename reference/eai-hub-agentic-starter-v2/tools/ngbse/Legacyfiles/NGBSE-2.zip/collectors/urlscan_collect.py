import os, json, time, hashlib, requests
from datetime import datetime, timedelta, timezone
from dotenv import load_dotenv

load_dotenv()
UA = os.getenv("USER_AGENT", "NGBSE-2/1.0 (+edu)")
API_KEY = os.getenv("URLSCAN_API_KEY", "")
BASE = "https://urlscan.io/api/v1/search/"
HDRS = {"User-Agent": UA, "Accept": "application/json"}
if API_KEY:
    HDRS["API-Key"] = API_KEY

def sha256s(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8", errors="ignore")).hexdigest()

def collect(seeds, raw_dir):
    out = []
    since = datetime.now(timezone.utc) - timedelta(days=7)  # configurable window
    for s in seeds:
        q = s.get("seed")
        if not q: 
            continue
        params = {"q": q}
        r = requests.get(BASE, headers=HDRS, params=params, timeout=30)
        if r.status_code != 200:
            continue
        data = r.json().get("results", [])
        for item in data:
            ts = item.get("indexedAt")
            if not ts:
                continue
            try:
                ts_dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
            except Exception:
                continue
            if ts_dt < since:
                continue
            # presence-only record
            rec = {
                "source": "urlscan",
                "seed": q,
                "priority": s.get("priority"),
                "why": s.get("why"),
                "result": {
                    "page": item.get("page", {}),
                    "task": item.get("task", {}),
                    "result_id": item.get("_id") or item.get("uuid") or item.get("task", {}).get("uuid")
                },
                "timestamp": ts
            }
            # chain-of-custody hash (of minimal concatenated fields)
            material = f"{rec['result'].get('result_id','')}|{rec['result']['page'].get('url','')}|{ts}"
            rec["coc_sha256"] = sha256s(material)
            out.append(rec)
    # write raw
    if out:
        raw_path = os.path.join(raw_dir, f"urlscan_{int(time.time())}.jsonl")
        with open(raw_path, "w", encoding="utf-8") as f:
            for r in out:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
    return out
