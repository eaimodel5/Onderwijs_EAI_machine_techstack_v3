import os, json, time, hashlib, requests
from datetime import datetime, timedelta, timezone

CDX = "https://web.archive.org/cdx/search/cdx"

def sha256s(s: str) -> str:
    import hashlib
    return hashlib.sha256(s.encode("utf-8", errors="ignore")).hexdigest()

# We look for mirrors relating to common admin/config keywords
DEFAULT_PATTERNS = [
    "citrix.com/*/release-notes/*",
    "docs.fortinet.com/*/admin*",
    "readthedocs.io/*/netscaler*",
    "*mqtt*/*config*",
]

def collect(seeds, raw_dir):
    out = []
    since_days = 365 * 2  # historical window; mirrors matter over long periods
    since_ts = int((datetime.utcnow() - timedelta(days=since_days)).timestamp())
    for pattern in DEFAULT_PATTERNS:
        params = {
            "url": pattern,
            "output": "json",
            "filter": "statuscode:200",
            "from": datetime.utcfromtimestamp(since_ts).strftime("%Y%m%d"),
        }
        try:
            r = requests.get(CDX, params=params, timeout=30)
            if r.status_code != 200:
                continue
            arr = r.json()
            # First row might be header
            for row in arr[1:] if arr and isinstance(arr, list) else []:
                urlkey, ts, original, mimetype, code, digest, length = row[:7]
                snapshot = f"https://web.archive.org/web/{ts}/{original}"
                rec = {
                    "source": "wayback",
                    "pattern": pattern,
                    "snapshot": snapshot,
                    "timestamp": ts,
                    "digest": digest,
                    "coc_sha256": sha256s(f"{snapshot}|{ts}|{digest}")
                }
                out.append(rec)
        except Exception:
            continue
    if out:
        raw_path = os.path.join(raw_dir, f"wayback_{int(time.time())}.jsonl")
        with open(raw_path, "w", encoding="utf-8") as f:
            for r in out:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
    return out
