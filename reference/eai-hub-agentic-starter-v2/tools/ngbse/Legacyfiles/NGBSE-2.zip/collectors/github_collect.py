import os, json, time, hashlib, requests
from datetime import datetime, timedelta, timezone
from dotenv import load_dotenv

load_dotenv()
GH = "https://api.github.com/search/code"
TOKEN = os.getenv("GITHUB_TOKEN", "")
UA = os.getenv("USER_AGENT", "NGBSE-2/1.0 (+edu)")
HDRS = {"User-Agent": UA, "Accept": "application/vnd.github+json"}
if TOKEN:
    HDRS["Authorization"] = f"Bearer {TOKEN}"

def sha256s(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8", errors="ignore")).hexdigest()

def collect(seeds, raw_dir):
    out = []
    for s in seeds:
        q = s.get("seed")
        params = {"q": q, "per_page": 30}
        try:
            r = requests.get(GH, headers=HDRS, params=params, timeout=30)
            if r.status_code != 200:
                continue
            data = r.json().get("items", [])
            for it in data:
                rec = {
                    "source": "github",
                    "seed": q,
                    "priority": s.get("priority"),
                    "why": s.get("why"),
                    "result": {
                        "name": it.get("name"),
                        "path": it.get("path"),
                        "repository": it.get("repository", {}).get("full_name"),
                        "html_url": it.get("html_url"),
                    },
                    "timestamp": datetime.utcnow().isoformat() + "Z"
                }
                material = f"{rec['result'].get('html_url','')}|{rec['result'].get('repository','')}"
                rec["coc_sha256"] = sha256s(material)
                out.append(rec)
        except Exception:
            continue
    if out:
        raw_path = os.path.join(raw_dir, f"github_{int(time.time())}.jsonl")
        with open(raw_path, "w", encoding="utf-8") as f:
            for r in out:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
    return out
