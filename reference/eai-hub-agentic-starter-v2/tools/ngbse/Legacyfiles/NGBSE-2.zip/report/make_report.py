import os, json, time, hashlib
from docx import Document

def main():
    base = os.path.join(os.path.dirname(__file__), "..")
    data_dir = os.path.join(base, "data")
    findings_path = os.path.join(data_dir, "findings.jsonl")
    mirror_json = os.path.join(data_dir, "mirror_score.json")
    doc = Document()
    doc.add_heading("NGBSE-2 Findings Report", level=1)
    doc.add_paragraph("Presence-only clearnet run. This report lists seeds, findings, and mirror factor M for blindspot detection (ghost assets).")

    # Summary
    live = []; mirrors = []
    if os.path.exists(findings_path):
        for line in open(findings_path, encoding="utf-8"):
            try:
                rec = json.loads(line)
            except Exception:
                continue
            if rec.get("source") == "wayback":
                mirrors.append(rec)
            else:
                live.append(rec)

    doc.add_heading("Summary", level=2)
    doc.add_paragraph(f"Live records: {len(live)}")
    doc.add_paragraph(f"Mirror records: {len(mirrors)}")

    # Mirror factor
    M = None
    if os.path.exists(mirror_json):
        try:
            M = json.load(open(mirror_json, encoding="utf-8")).get("M", None)
        except Exception:
            M = None
    doc.add_paragraph(f"Mirror factor (M): {M if M is not None else 'N/A'}")

    # Findings table (truncated to top 50 for readability)
    doc.add_heading("Findings (top 50)", level=2)
    table = doc.add_table(rows=1, cols=5)
    hdr = table.rows[0].cells
    hdr[0].text = "Source"
    hdr[1].text = "Seed/Pattern"
    hdr[2].text = "Result ID / URL"
    hdr[3].text = "Timestamp"
    hdr[4].text = "CoC SHA-256"

    def add_row(src, seed, rid, ts, sha):
        row = table.add_row().cells
        row[0].text = src
        row[1].text = seed
        row[2].text = rid
        row[3].text = ts
        row[4].text = sha

    for rec in (live + mirrors)[:50]:
        if rec.get("source") == "urlscan":
            rid = rec["result"].get("result_id") or rec["result"]["page"].get("url","")
            add_row("urlscan", rec.get("seed",""), str(rid), rec.get("timestamp",""), rec.get("coc_sha256",""))
        elif rec.get("source") == "github":
            rid = rec["result"].get("html_url","")
            add_row("github", rec.get("seed",""), rid, rec.get("timestamp",""), rec.get("coc_sha256",""))
        elif rec.get("source") == "wayback":
            add_row("wayback", rec.get("pattern",""), rec.get("snapshot",""), rec.get("timestamp",""), rec.get("coc_sha256",""))

    out_path = os.path.join(base, "docs", "NGBSE-2_Findings_Report.docx")
    doc.save(out_path)
    print(f"[OK] Report written: {out_path}")

if __name__ == "__main__":
    main()
