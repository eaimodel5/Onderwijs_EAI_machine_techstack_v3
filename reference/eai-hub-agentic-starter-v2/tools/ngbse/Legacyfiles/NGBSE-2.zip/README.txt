NGBSE-2 bundle generated.
