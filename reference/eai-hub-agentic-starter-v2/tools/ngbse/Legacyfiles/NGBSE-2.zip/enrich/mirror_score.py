import json, os, time, hashlib


def calc_m(live_records, mirror_records):
    # naive heuristic: M = min(1.0, mirrors / max(1, lives)) with floor 0.1 if nothing
    lives = len(live_records)
    mirrors = len(mirror_records)
    if mirrors == 0:
        return 0.1
    if lives == 0 and mirrors > 0:
        return 1.0
    ratio = mirrors / max(1, lives)
    return max(0.2, min(1.0, ratio))

def main():
    data_dir = os.path.join(os.path.dirname(__file__), "..", "data")
    findings_path = os.path.join(data_dir, "findings.jsonl")
    live = []
    mirrors = []
    if os.path.exists(findings_path):
        for line in open(findings_path, encoding="utf-8"):
            try:
                rec = json.loads(line)
            except Exception:
                continue
            if rec.get("source") == "wayback":
                mirrors.append(rec)
            else:
                live.append(rec)
    M = calc_m(live, mirrors)
    out = {"M": M, "live_count": len(live), "mirror_count": len(mirrors), "timestamp": time.time()}
    with open(os.path.join(data_dir, "mirror_score.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    print(f"[OK] Mirror factor M={M:.2f} (live={len(live)} mirrors={len(mirrors)})")

if __name__ == "__main__":
    main()
