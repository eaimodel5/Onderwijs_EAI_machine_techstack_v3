import os, json, time, sys
from dotenv import load_dotenv

load_dotenv()

DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")
COLLECTORS_DIR = os.path.join(os.path.dirname(__file__), "..", "collectors")
RAW_DIR = os.path.join(DATA_DIR, "raw")
os.makedirs(RAW_DIR, exist_ok=True)

# Lightweight router: import collectors lazily
def run_urlscan(seeds):
    from collectors.urlscan_collect import collect as urlscan_collect
    return urlscan_collect(seeds, RAW_DIR)

def run_github(seeds):
    from collectors.github_collect import collect as github_collect
    return github_collect(seeds, RAW_DIR)

def run_wayback(seeds):
    from collectors.wayback_collect import collect as wayback_collect
    return wayback_collect(seeds, RAW_DIR)

# Optional hooks (stubs by default)
def run_censys(seeds):
    # Placeholder for later; presence-only meta recommended
    return []

def run_shodan(seeds):
    return []

def run_leakix(seeds):
    return []

def main():
    seeds_path = os.path.join(DATA_DIR, "seeds.jsonl")
    if not os.path.exists(seeds_path):
        print("No seeds.jsonl found")
        sys.exit(1)

    seeds = [json.loads(l) for l in open(seeds_path, encoding="utf-8")]
    buckets = {}
    for s in seeds:
        buckets.setdefault(s["where"], []).append(s)

    # Always run Wayback mirrors for ghost-asset detection
    wayback_out = run_wayback(seeds)

    results = []
    if "urlscan" in buckets:
        results += run_urlscan(buckets["urlscan"])
    if "github" in buckets:
        results += run_github(buckets["github"])
    if "censys" in buckets:
        results += run_censys(buckets["censys"])
    if "shodan" in buckets:
        results += run_shodan(buckets["shodan"])
    if "leakix" in buckets:
        results += run_leakix(buckets["leakix"])

    # Merge minimal outputs
    out_path = os.path.join(DATA_DIR, "findings.jsonl")
    with open(out_path, "w", encoding="utf-8") as f:
        for r in results + wayback_out:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

    print(f"[OK] Findings written: {out_path}")

if __name__ == "__main__":
    main()
