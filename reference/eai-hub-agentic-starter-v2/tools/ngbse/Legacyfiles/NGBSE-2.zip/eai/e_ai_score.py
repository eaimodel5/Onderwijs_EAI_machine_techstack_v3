import os, json, math

# E_AI* with Mirror factor (w5=0.05, V weight reduced to 0.15 to keep sum 1.0)
def e_ai_star(P, W_V, D_A, D_B, T, A, V, M, w1=0.3, w2=0.3, w3=0.2, w4=0.15, w5=0.05):
    return math.sqrt(w1*(P*W_V) + w2*(D_A*D_B) + w3*(T*A) + w4*V + w5*M)

def main():
    # example conservative values
    P, W_V, D_A, D_B, T, A, V = 0.70, 0.85, 0.80, 0.70, 0.80, 0.55, 0.80
    # load mirror factor if available
    data_dir = os.path.join(os.path.dirname(__file__), "..", "data")
    mirror_json = os.path.join(data_dir, "mirror_score.json")
    M = 0.5
    if os.path.exists(mirror_json):
        try:
            M = json.load(open(mirror_json, encoding="utf-8")).get("M", 0.5)
        except Exception:
            pass
    score = e_ai_star(P, W_V, D_A, D_B, T, A, V, M)
    print(f"E_AI* = {score:.3f} (with M={M:.2f})")

if __name__ == "__main__":
    main()
