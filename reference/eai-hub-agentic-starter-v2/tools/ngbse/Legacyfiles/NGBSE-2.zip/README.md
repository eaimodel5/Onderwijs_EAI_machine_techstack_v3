# NGBSE-2 — Next Gen Blind Spot Engine (NL, clearnet, reverse-LLM)

Presence-only data collection for blindspot detection (JSCU-style). 
No logins, no TOR, no content downloads. Chain-of-custody hashes included.

## Quickstart
```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env  # (fill API keys if available)
./run.sh
```

## Workflow
- `engine/orchestrator.py` reads `data/seeds.jsonl` and routes to collectors
- `collectors/` call clearnet APIs (urlscan, wayback, github). Output -> `data/findings.jsonl`
- `enrich/mirror_score.py` computes Mirror factor M (ghost assets signal)
- `eai/e_ai_score.py` computes E_AI* including M
- `report/make_report.py` writes `docs/NGBSE-2_Findings_Report.docx`

## Data policy
- Presence-only: we record result IDs, URLs, timestamps, and SHA-256 of minimal strings.
- No content extraction or private data; this stays inside legal OSINT boundaries.
