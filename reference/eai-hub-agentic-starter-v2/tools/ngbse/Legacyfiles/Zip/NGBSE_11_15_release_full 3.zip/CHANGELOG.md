## 11.15
- Online-only LLM (OpenAI/Azure/Anthropic) via `engine/llm_client.py`
- Predictive synthesis & Reverse LLM gebruiken nu de online client
- LeakIX collector opgeschoond en online-only
- Versie bump vanuit 11.1, overige functionaliteit behouden
