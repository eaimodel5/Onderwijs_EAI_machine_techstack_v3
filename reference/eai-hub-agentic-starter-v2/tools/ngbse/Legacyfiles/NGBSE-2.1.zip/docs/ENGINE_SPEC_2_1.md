# NGBSE 2.1 Engine Spec

This document describes the architecture and formula extensions.
