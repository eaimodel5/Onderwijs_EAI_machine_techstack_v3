# Blindspot Rubric

Internal rubric details are restricted.
