# Changelog
- 2025-08-16 — v2.1 initial release (clearnet OSINT + E_AI scoring + 7‑day scenarios).
