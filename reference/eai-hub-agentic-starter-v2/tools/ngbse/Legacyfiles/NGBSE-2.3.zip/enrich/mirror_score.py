
def mirror_factor(records):
    """
    Compute M in [0.1,1.0]. If a seed has wayback presence but no live presence,
    return high M (ghost asset). If both live and mirror, medium. If only live, low.
    """
    by_seed = {}
    for r in records:
        key = (r.get("seed"), r.get("source"))
        by_seed.setdefault(r.get("seed"), set()).add(r.get("source"))
    M = 0.1
    for seed, sources in by_seed.items():
        if "wayback" in sources and ("urlscan" not in sources and "censys" not in sources and "leakix" not in sources and "shodan" not in sources and "github" not in sources):
            M = max(M, 1.0)
        elif "wayback" in sources:
            M = max(M, 0.6)
        else:
            M = max(M, 0.2)
    return round(M,2)
