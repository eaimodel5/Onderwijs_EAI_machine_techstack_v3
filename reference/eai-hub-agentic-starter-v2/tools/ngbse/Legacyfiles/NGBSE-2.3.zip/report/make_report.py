
from docx import Document
from pathlib import Path
import json, time
from enrich.mirror_score import mirror_factor
from eai.e_ai_score import e_ai_star

def build_report(findings_path, out_path="out/NGBSE-2.3_Findings_Report.docx"):
    doc = Document()
    doc.add_heading("NGBSE 2.3 — Findings Report (clearnet presence-only)", 0)
    with open(findings_path) as f:
        records = [json.loads(x) for x in f if x.strip()]
    doc.add_paragraph(f"Total records: {len(records)}")
    M = mirror_factor(records)
    doc.add_paragraph(f"Mirror factor (M): {M}")
    # Simple demo E_AI* computation with placeholder params
    score = e_ai_star(P=0.7,W_V=0.8,D_A=0.8,D_B=0.7,T=0.7,A=0.6,V=0.75,M=M,Q=0.7,C=2)
    doc.add_paragraph(f"E_AI*: {score}")
    table = doc.add_table(rows=1, cols=4)
    hdr = table.rows[0].cells
    hdr[0].text, hdr[1].text, hdr[2].text, hdr[3].text = "Source","Seed","URL","Hash"
    for r in records[:50]:
        row = table.add_row().cells
        row[0].text = str(r.get("source"))
        row[1].text = str(r.get("seed"))
        row[2].text = str(r.get("url"))
        row[3].text = str(r.get("hash"))
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    doc.save(out_path)
    return out_path

if __name__=="__main__":
    build_report("out/findings.jsonl")
