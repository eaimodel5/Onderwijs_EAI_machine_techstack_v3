
import json, hashlib, time
from pathlib import Path

def sha256_text(txt:str)->str:
    return hashlib.sha256(txt.encode("utf-8","ignore")).hexdigest()

def load_seeds(path):
    seeds = []
    with open(path) as f:
        for line in f:
            line=line.strip()
            if not line: 
                continue
            seeds.append(json.loads(line))
    return seeds

def log_record(path, obj):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    obj["ts"] = int(time.time())
    with open(path,"a") as f:
        f.write(json.dumps(obj, ensure_ascii=False) + "\n")
