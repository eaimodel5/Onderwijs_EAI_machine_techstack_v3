
import json, time, os
from pathlib import Path
from collectors.urlscan_collect import collect as urlscan_collect
from collectors.github_collect import collect as github_collect
from collectors.wayback_collect import collect as wayback_collect
from collectors.censys_collect import collect as censys_collect
from collectors.leakix_collect import collect as leakix_collect
from collectors.shodan_collect import collect as shodan_collect
from engine.util import load_seeds, log_record, sha256_text

COLLECTORS = {
    "urlscan": urlscan_collect,
    "github": github_collect,
    "wayback": wayback_collect,
    "censys": censys_collect,
    "leakix": leakix_collect,
    "shodan": shodan_collect
}

def run(seed_file, out_file="out/findings.jsonl", throttle=0.2):
    seeds = load_seeds(seed_file)
    Path(out_file).parent.mkdir(parents=True, exist_ok=True)
    seen = set()
    for s in seeds:
        where = s.get("where")
        if where not in COLLECTORS: 
            continue
        q = s["seed"]
        key = f"{where}|{q}"
        if key in seen: 
            continue
        seen.add(key)
        for rec in COLLECTORS[where](q):
            # enforce presence-only by hashing snippet/URL and storing meta
            rec["hash"] = sha256_text((rec.get("url") or "") + (rec.get("snippet") or ""))
            rec["source"] = where
            rec["seed"] = q
            log_record(out_file, rec)
        time.sleep(throttle)
    return out_file

if __name__ == "__main__":
    run("data/seeds.jsonl")
