
def collect(query:str):
    # Presence-only placeholder: in production, call the respective API.
    # Here we just yield a structure showing what would be logged.
    # This avoids any network calls and stays within legal boundaries.
    yield {"url": f"https://example.com/search?q={query}", "snippet": f"Presence for {query}", "title": "presence"}
