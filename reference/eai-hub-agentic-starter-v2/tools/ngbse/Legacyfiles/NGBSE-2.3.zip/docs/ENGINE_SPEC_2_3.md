# NGBSE 2.3 Engine Spec

Includes balance metric: evidence vs examples.
