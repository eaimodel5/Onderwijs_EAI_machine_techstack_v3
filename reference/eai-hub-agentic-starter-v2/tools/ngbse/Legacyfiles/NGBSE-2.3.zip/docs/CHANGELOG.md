
# NGBSE 2.3 — Changelog

## Blindspots found in 2.0
- No mirror factor (ghost assets invisible).
- Dummy/example data biased E_AI and narratives.
- No presence-only enforcement across collectors.
- No chain-of-custody hashing at collector stage.
- No disambiguation (e.g., "DJI" vs Dienst Justitiële Inrichtingen).
- No sector/source tagging and trust weighting.

## Blindspots found in 2.2
- Corroboration not measured; single-source evidence over-weighted.
- Evidence quality not scored (noise vs primary source).
- Timezone/recency normalization missing (EU/Amsterdam).
- Probability model too naive (linear/decay only).
- No seed dedup/backoff & rate-limit strategy.

## What 2.3 adds
- E_AI* with M (mirror), Q (evidence quality) and C (corroboration).
- Presence-only enforcement and SHA-256 hashing in collectors.
- Ghost-asset detection via Wayback presence.
- Seed deduplication and throttle in orchestrator.
- Europe/Amsterdam timestamping downstream (doc in Manual).
- Disambiguation notes for acronym collisions.
- Report generator producing a docx with CoC table.
