# Manual
Run: python -m engine.orchestrator data/seeds.jsonl && python -m report.make_report
