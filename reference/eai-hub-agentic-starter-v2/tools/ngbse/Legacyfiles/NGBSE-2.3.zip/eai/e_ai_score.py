
import math

def e_ai_star(P,W_V,D_A,D_B,T,A,V,M=0.0,Q=0.6,C=1):
    """
    Extended E_AI*: adds Mirror factor (M), Evidence quality (Q) and Corroboration (C).
    We fold Q and C into V (validity) as V' = min(1.0, 0.5*V + 0.3*Q + 0.2*min(1.0,C/3)).
    """
    Vp = min(1.0, 0.5*V + 0.3*Q + 0.2*min(1.0, C/3))
    w1,w2,w3,w4,w5 = 0.3,0.3,0.2,0.15,0.05
    return round(math.sqrt(w1*(P*W_V)+w2*(D_A*D_B)+w3*(T*A)+w4*Vp+w5*M),3)
